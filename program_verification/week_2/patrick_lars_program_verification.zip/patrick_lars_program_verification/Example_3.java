public class Example {

    public int count_to_five(int n1, int n2) {
        int i = 0;
        while (i < 5) {
//            i >= 0 && i <= 3
            int i = i + 1;
        }
        return i;
    }
}
